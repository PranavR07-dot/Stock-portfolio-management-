DROP DATABASE IF EXISTS customer_test;
CREATE DATABASE customer_test;